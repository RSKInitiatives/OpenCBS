SELECT 
	Cont.contract_code, 
	Dts.name AS [district], 
	Pack.name AS [loan_product],
	coalesce(corp.name, Gr.name, Pers.first_name, '') as client_first_name,
	ISNULL(Gr.name,ISNULL(Pers.last_name, '')) AS [client_last_name],
	Trs.loan_cycle,
	Us.first_name + SPACE(1) + Us.last_name AS [loan_officer], 
	Br.code AS branch_name, 
	Dis.disbursement_date, 
	Dis.amount, 
	Dis.interest, 
	Dis.fees  
FROM dbo.Disbursements_MC(@start_date, @end_date, @disbursed_in, @display_in, @user_id, @subordinate_id, @branch_id) AS Dis
LEFT JOIN dbo.Credit AS Cr ON Cr.id = Dis.contract_id
LEFT JOIN dbo.Contracts AS Cont ON Dis.contract_id = Cont.id
LEFT JOIN dbo.Projects AS Pr ON Cont.project_id = Pr.id
LEFT JOIN dbo.Groups AS Gr ON Gr.id = Pr.tiers_id
LEFT JOIN dbo.Persons AS Pers ON Pers.id = Pr.tiers_id
left join dbo.Corporates corp on corp.id = Pr.tiers_id
LEFT JOIN dbo.Tiers AS Trs ON Pr.tiers_id = Trs.id
LEFT JOIN dbo.Branches Br ON Br.id = Trs.branch_id
LEFT JOIN dbo.Districts AS Dts ON Dts.id = Trs.district_id
LEFT JOIN dbo.Users AS Us ON Cr.loanofficer_id = Us.id
LEFT JOIN dbo.Packages AS Pack ON Cr.package_id = Pack.id
WHERE Dis.disbursement_date BETWEEN @start_date AND dateadd(day, 1, cast(@end_date as date))
	AND Dis.disbursed = 1
order by Dis.disbursement_date