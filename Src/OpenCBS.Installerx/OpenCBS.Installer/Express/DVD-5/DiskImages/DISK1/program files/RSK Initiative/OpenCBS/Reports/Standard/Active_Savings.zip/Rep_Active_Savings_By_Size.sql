CREATE PROCEDURE Rep_Active_Savings_By_Size
@pDate DATETIME, 
@disbursed_in INT, 
@display_in INT
, @branch_id INT
AS
BEGIN 
  
 SELECT 
   CASE sp.product_type
			WHEN 'B' THEN 'Savings Book'
			WHEN 'T' THEN 'Savings Deposit'
			WHEN 'C' THEN 'Compulsory Savings'
		END AS product_type, 
   COUNT(*) AS contracts,
   ls.ScaleMin AS [from],
   ls.ScaleMax AS [to],
   SUM(asl.balance) AS balance
 FROM ActiveSavingAccounts_MC(@pDate,@disbursed_in,@display_in, @branch_id) asl
 INNER JOIN SavingContracts sc ON sc.id = asl.contract_id
 INNER JOIN SavingProducts sp ON sp.id = sc.product_id
 LEFT JOIN LoanScale ls ON asl.balance>=ls.ScaleMin AND asl.balance <= ls.ScaleMax
 GROUP BY sp.product_type,ls.ScaleMin,ls.ScaleMax
 ORDER BY sp.product_type,ls.ScaleMin,ls.ScaleMax 
END
