--if not OBJECT_ID('Rep_Active_Loans') is null
--drop procedure dbo.Rep_Active_Loans
--go

CREATE PROCEDURE dbo.Rep_Active_Loans @date DATETIME, @disbursed_in INT, @display_in INT, @branch_id NVARCHAR(MAX), @user_id INT, @subordinate_id INT
AS BEGIN
		DECLARE @active_clients TABLE
		(
			id INT NOT NULL
			, contract_id INT NOT NULL
			, olb MONEY NOT NULL
			, amount MONEY NOT NULL
			, client_type_code CHAR(1) NOT NULL
			, package_id INT NOT NULL
			, activity_id INT NOT NULL
			, district_id INT NOT NULL
			, interest_rate FLOAT NOT NULL
			, installment_type_id INT NOT NULL
			, loan_officer_id INT NOT NULL
			, branch_id INT NOT NULL
			, row INT NOT NULL
		)

		DECLARE @active_loans TABLE
		(
			contract_id INT NOT NULL
			, amount MONEY NOT NULL
		)

		DECLARE @users TABLE
		(
			id INT NOT NULL
		)
		
		INSERT INTO @users
		SELECT @user_id
		INSERT INTO @users
		SELECT subordinate_id
		FROM dbo.UsersSubordinates
		WHERE user_id = @user_id

		INSERT INTO @active_clients
		SELECT ac.id
		, ac.contract_id
		, ac.olb
		, ac.amount
		, t.client_type_code
		, cr.package_id
		, c.activity_id
		, t.district_id
		, cr.interest_rate
		, pack.installment_type
		, cr.loanofficer_id
		, t.branch_id
		, ROW_NUMBER() OVER (PARTITION BY ac.contract_id ORDER BY ac.contract_id) row
		FROM dbo.ActiveClients_MC(@date, @disbursed_in, @display_in, 0) ac
		INNER JOIN dbo.Contracts c on c.id = ac.contract_id
		INNER JOIN dbo.Credit cr on cr.id = c.id
		INNER JOIN dbo.Projects j on j.id = c.project_id
		INNER JOIN dbo.Tiers t on t.id = j.tiers_id
		LEFT JOIN dbo.Packages pack ON pack.id = cr.package_id		
		WHERE (0 = @subordinate_id AND cr.loanofficer_id IN (SELECT id FROM @users) OR cr.loanofficer_id = @subordinate_id) AND
		      ('0' = @branch_id OR t.branch_id IN (SELECT number FROM dbo.IntListToTable(@branch_id)))

		INSERT INTO @active_loans
		SELECT contract_id, SUM(amount)
		FROM @active_clients
		GROUP BY contract_id

		DECLARE @retval TABLE
		(
			break_down NVARCHAR(100) NULL
			, break_down_type VARCHAR(20) NOT NULL
			, contracts INT NOT NULL
			, individual INT NOT NULL
			, [group] INT NOT NULL
			, corporate INT NOT NULL
			, clients INT NOT NULL
			, in_groups INT NOT NULL
			, projects INT NOT NULL
			, olb MONEY NOT NULL
		)

		INSERT INTO @retval
		SELECT pack.name break_down
		, 'product' break_down_type
		, COUNT(DISTINCT ac.contract_id) contracts
		, SUM(CASE WHEN 'I' = ac.client_type_code THEN 1 ELSE 0 END) individual
		, SUM(CASE WHEN 'G' = ac.client_type_code AND 1 = ac.row THEN 1 ELSE 0 END) [group]
		, SUM(CASE WHEN 'C' = ac.client_type_code THEN 1 ELSE 0 END) corporate
		, COUNT(DISTINCT ac.id) clients
		, COUNT(DISTINCT CASE WHEN ac.client_type_code = 'G' THEN ac.id ELSE null END) in_groups
		, COUNT(DISTINCT ac.contract_id) projects
		, SUM(olb) olb    
		FROM @active_clients ac
		INNER JOIN dbo.Packages pack on pack.id = ac.package_id
		GROUP BY ac.package_id, pack.name
		ORDER BY pack.name

		INSERT INTO @retval
		SELECT doa.name break_down
		, 'activity' break_down_type
		, count(distinct ac.contract_id) as contracts
		, SUM(CASE WHEN 'I' = ac.client_type_code THEN 1 ELSE 0 END) individual
		, 0 [group]
		, SUM(CASE WHEN 'C' = ac.client_type_code THEN 1 ELSE 0 END) corporate
		, COUNT(DISTINCT ac.id) clients
		, COUNT(DISTINCT CASE WHEN ac.client_type_code = 'G' THEN ac.id ELSE null END) in_groups
		, 0 projects
		, SUM(olb) olb    
		FROM @active_clients ac
		LEFT JOIN dbo.EconomicActivities doa on doa.id = ac.activity_id
		GROUP BY ac.activity_id, doa.name
		ORDER BY doa.name

		INSERT INTO @retval
		SELECT d.name break_down
		, 'district' break_down_type
		, COUNT(DISTINCT ac.contract_id) contracts
		, SUM(CASE WHEN 'I' = ac.client_type_code THEN 1 ELSE 0 END) individual
		, SUM(CASE WHEN 'G' = ac.client_type_code AND 1 = ac.row THEN 1 ELSE 0 END) [group]
		, SUM(CASE WHEN 'C' = ac.client_type_code THEN 1 ELSE 0 END) corporate
		, COUNT(DISTINCT ac.id) clients
		, COUNT(DISTINCT CASE WHEN ac.client_type_code = 'G' THEN ac.id ELSE null END) in_groups
		, COUNT(DISTINCT ac.contract_id) projects
		, SUM(olb) olb    
		FROM @active_clients ac
		LEFT JOIN dbo.Districts d ON d.id = ac.district_id
		GROUP BY ac.district_id, d.name
		ORDER BY d.name
		
		INSERT INTO @retval
		SELECT cur.name break_down
		, 'currency' break_down_type
		, COUNT(DISTINCT ac.contract_id) contracts
		, SUM(CASE WHEN 'I' = ac.client_type_code THEN 1 ELSE 0 END) individual
		, SUM(CASE WHEN 'G' = ac.client_type_code AND 1 = ac.row THEN 1 ELSE 0 END) [group]
		, SUM(CASE WHEN 'C' = ac.client_type_code THEN 1 ELSE 0 END) corporate
		, COUNT(DISTINCT ac.id) clients
		, COUNT(DISTINCT CASE WHEN ac.client_type_code = 'G' THEN ac.id ELSE null END) in_groups
		, COUNT(DISTINCT ac.contract_id) projects
		, SUM(olb) olb 
		FROM @active_clients ac
		INNER JOIN dbo.Packages pack ON pack.id = ac.package_id
		INNER JOIN dbo.Currencies cur ON cur.id = pack.currency_id
		GROUP BY cur.id, cur.name
		ORDER BY cur.name

		INSERT INTO @retval
		SELECT CAST(ac.interest_rate * 100 AS NVARCHAR(100)) + '% ' break_down
		, 'interest_rate' break_down_type
		, COUNT(DISTINCT ac.contract_id) contracts
		, SUM(CASE WHEN 'I' = ac.client_type_code THEN 1 ELSE 0 END) individual
		, SUM(CASE WHEN 'G' = ac.client_type_code AND 1 = ac.row THEN 1 ELSE 0 END) [group]
		, SUM(CASE WHEN 'C' = ac.client_type_code THEN 1 ELSE 0 END) corporate
		, COUNT(DISTINCT ac.id) clients
		, COUNT(DISTINCT CASE WHEN ac.client_type_code = 'G' THEN ac.id ELSE null END) in_groups
		, COUNT(DISTINCT ac.contract_id) projects
		, SUM(olb) olb    
		FROM @active_clients ac
		LEFT JOIN dbo.InstallmentTypes it ON it.id = ac.installment_type_id
		GROUP BY ac.interest_rate, it.name
		ORDER BY it.name, ac.interest_rate

		INSERT INTO @retval
		SELECT u.first_name + ' ' + u.last_name break_down
		, 'loan_officer' break_down_type
		, COUNT(DISTINCT ac.contract_id) contracts
		, SUM(CASE WHEN 'I' = ac.client_type_code THEN 1 ELSE 0 END) individual
		, SUM(CASE WHEN 'G' = ac.client_type_code AND 1 = ac.row THEN 1 ELSE 0 END) [group]
		, SUM(CASE WHEN 'C' = ac.client_type_code THEN 1 ELSE 0 END) corporate
		, COUNT(DISTINCT ac.id) clients
		, COUNT(DISTINCT CASE WHEN ac.client_type_code = 'G' THEN ac.id ELSE null END) in_groups
		, COUNT(DISTINCT ac.contract_id) projects
		, SUM(olb) olb    
		FROM @active_clients ac
		LEFT JOIN dbo.Users u ON u.id = ac.loan_officer_id
		GROUP BY u.first_name, u.last_name
		ORDER BY u.first_name + ' ' + u.last_name
		
		INSERT INTO @retval
		SELECT b.name break_down
		, 'branch' break_down_type
		, COUNT(DISTINCT ac.contract_id) contracts
		, SUM(CASE WHEN 'I' = ac.client_type_code THEN 1 ELSE 0 END) individual
		, SUM(CASE WHEN 'G' = ac.client_type_code AND 1 = ac.row THEN 1 ELSE 0 END) [group]
		, SUM(CASE WHEN 'C' = ac.client_type_code THEN 1 ELSE 0 END) corporate
		, COUNT(DISTINCT ac.id) clients
		, COUNT(DISTINCT CASE WHEN ac.client_type_code = 'G' THEN ac.id ELSE null END) in_groups
		, COUNT(DISTINCT ac.contract_id) projects
		, SUM(olb) olb    
		FROM @active_clients ac
		LEFT JOIN dbo.Branches b ON b.id = ac.branch_id
		GROUP BY b.id, b.name
		ORDER BY b.name

		INSERT INTO @retval
		SELECT CAST(ls.ScaleMin AS NVARCHAR(20)) + ' - ' + CAST(ls.ScaleMax AS NVARCHAR(20)) break_down
		, 'loan_size' break_down_type
		, count(distinct ac.contract_id) contracts
		, SUM(CASE WHEN 'I' = ac.client_type_code THEN 1 ELSE 0 END) individual
		, 0 [group]
		, 0 corporate
		, COUNT(DISTINCT ac.id) clients
		, COUNT(DISTINCT CASE WHEN ac.client_type_code = 'G' THEN ac.id ELSE null END) in_groups
		, 0 projects
		, SUM(olb) olb    
		FROM @active_clients ac
		LEFT JOIN dbo.LoanScale ls ON ac.amount > ls.ScaleMin AND ac.amount <= ls.ScaleMax
		GROUP BY ls.id, ls.ScaleMin, ls.ScaleMax
		ORDER BY ls.ScaleMin
		SELECT * FROM @retval
END
