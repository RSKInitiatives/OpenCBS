--declare @contract_id INT = 12




SELECT  COALESCE(pe.first_name+ ' ' +pe.last_name+' '+pe.father_name,
					 pe.first_name+' '+pe.last_name,
					 gr.name,
					 corp.name) AS beneficiary_name,
					 pe.identification_data AS identification_data,
			co.contract_code AS contract_code,
			u.first_name + ' ' + u.last_name AS loan_officer_name,
			ce.event_date AS paid_date,
			cr.insurance,
			cu.code AS symbol_currency,
			ISNULL(ce.comment, ' ') AS comment,
			br.name as branch,
			ISNULL(dbo.getEntryFees(@contract_id), 0) AS entry_fees,
			(SELECT [value]
		FROM [GeneralParameters] WHERE [KEY] = 'MFI_NAME') AS mfi_name
	FROM    Contracts co 
			INNER JOIN Projects pr ON co.project_id = pr.id
			INNER JOIN Tiers ti ON pr.tiers_id = ti.id
			INNER JOIN Credit cr ON co.id = cr.id
			INNER JOIN Users u ON cr.loanofficer_id = u.id
			INNER JOIN ContractEvents ce ON ce.contract_id = co.id
			INNER JOIN LoanDisbursmentEvents lde ON lde.id = ce.id
			INNER JOIN Currencies cu ON cu.id=1
			INNER JOIN Branches br ON br.code = co.branch_code
			LEFT JOIN Persons pe ON pe.id = ti.id
			LEFT JOIN Groups gr ON gr.id = ti.id
			LEFT JOIN Corporates corp ON corp.id = ti.id						
	WHERE   co.id = @contract_id AND ce.is_deleted = 0 AND cu.id=1 

	
	
	SELECT COALESCE(pe.first_name+' '+ISNULL(pe.last_name,'')+' '+ISNULL(pe.father_name,''),					
					pe2.first_name+' '+ISNULL(pe2.last_name,'')+' '+ISNULL(pe2.father_name,''),
					corp.name) AS member_name,
	  COALESCE(lsa.amount,cr.amount) AS loan_share_amount,
	  COALESCE(pe.identification_data,pe2.identification_data) AS identification_data
	FROM Contracts co
	INNER JOIN Credit cr ON co.id = cr.id
	INNER JOIN Projects pr ON co.project_id = pr.id
	INNER JOIN Tiers ti ON ti.id = pr.tiers_id
	LEFT JOIN Persons pe ON pe.id = ti.id
	LEFT JOIN LoanShareAmounts lsa ON lsa.contract_id = co.id AND lsa.group_id = ti.id
	LEFT JOIN Persons pe2 ON pe2.id = lsa.person_id
	LEFT JOIN Corporates corp ON corp.id = ti.id
	WHERE co.id = @contract_id
	
	
	
	