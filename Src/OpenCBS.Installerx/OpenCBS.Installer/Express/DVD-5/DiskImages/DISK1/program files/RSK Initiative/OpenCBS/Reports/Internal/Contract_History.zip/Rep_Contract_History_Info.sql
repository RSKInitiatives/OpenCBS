CREATE PROCEDURE [dbo].[Rep_Contract_History_Info] @contract_id int
AS 
BEGIN
	SELECT  co.contract_code,
	co.[start_date],
	cr.amount,
	dbo.getEntryFees(@contract_id) AS entry_fees,
	cr.[nb_of_installment],
	cr.interest_rate*100 as interest_rate,
	curr.name as currency_name,
	u.first_name + ' ' + u.last_name AS loan_officer,
	COALESCE(pe.first_name + ' ' + pe.last_name, gr.name,corp.name) AS client_name,	
	COALESCE(pe.identification_data, corp.siret) AS passport	
FROM Contracts co
INNER JOIN Credit cr ON co.id = cr.id
INNER JOIN Packages pkg ON cr.package_id=pkg.id
INNER JOIN Currencies curr ON pkg.currency_id=curr.id
INNER JOIN Users u ON cr.loanofficer_id = u.id
INNER JOIN Projects pr ON co.project_id = pr.id
INNER JOIN Tiers ti ON ti.id = pr.tiers_id 
LEFT JOIN Persons pe ON pe.id = ti.id 
LEFT JOIN Groups gr ON gr.id=ti.id
LEFT JOIN Corporates corp ON corp.id = ti.id
WHERE co.id = @contract_id
END
