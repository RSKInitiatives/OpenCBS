CREATE PROCEDURE [dbo].[Rep_Teller_Events] 
    @from DATETIME
    , @to DATETIME
    , @user INT
	, @teller INT
	, @branch INT
    , @include_deleted BIT
AS 
BEGIN
    SELECT 
		[date], 
		fees, 
		amount, 
		code, 
		account,
		pending,
		ISNULL(reference_number, '') as reference_number,
		ISNULL(description, '') as description,
		deleted,
		cancel_date,
		user_name, 
		teller_name,	  
		branch_name
    FROM TellerEventsHistory(@from, @to, @user, @teller, @branch, @include_deleted) 
END
