CREATE PROCEDURE dbo.Rep_Saving_Contract_Events @saving_id INT
AS
BEGIN
	SELECT 
	[date], value_date, event_type,
	fees, debit, credit
	FROM
	(
	-- Debit
	SELECT 
	[SavingEvents].id,
	SavingEvents.code,
	[SavingEvents].creation_date AS [date],
	[SavingEvents].creation_date AS [value_date],
	CASE SavingEvents.code
	WHEN 'SVWE' THEN 'Withdrawal'
	WHEN 'SDTE' THEN 'Debit Transfer'
	WHEN 'SODE' THEN 'Special Operation Debit'
	END AS [event_type], 
	fees,
	amount AS [debit],
	0 AS [credit],
	[description],
	Currencies.code as [currency_code]	
	FROM [dbo].[SavingEvents]
	INNER JOIN [dbo].[SavingContracts] ON SavingContracts.id = SavingEvents.contract_id
	INNER JOIN [dbo].[SavingProducts] ON SavingContracts.product_id = SavingProducts.id
	INNER JOIN [dbo].[Currencies] ON SavingProducts.currency_id = Currencies.id
	WHERE contract_id = @saving_id AND SavingEvents.deleted = 0
	AND SavingEvents.code IN ('SVWE', 'SDTE', 'SODE') 

	UNION ALL

	-- Credit
	SELECT 
	[SavingEvents].id,
	SavingEvents.code,
	[SavingEvents].creation_date AS [date],
	[SavingEvents].creation_date AS [value_date],
	CASE SavingEvents.code
	WHEN 'SVIE' THEN 'Initial Deposit'
	WHEN 'SVDE' THEN 'Deposit'
	WHEN 'SIPE' THEN 'Interest Posting'
	WHEN 'SCTE' THEN 'Credit Transfer'
	WHEN 'SOCE' THEN 'Special Operation Credit'
	WHEN 'SOFE' THEN 'Overdraft Fees'
	WHEN 'SVAE' THEN 'Agio'
	WHEN 'SVDC' THEN 'Deposit Cheque'
	WHEN 'SVRE' THEN 'Reopen'
	WHEN 'SMFE' THEN 'Management Fee'
	WHEN 'SVCE' THEN 'Closing'
	WHEN 'SVLD' THEN 'Savings Loan Disbursement'
	
	WHEN 'SIFE' THEN 'Savings Instrument Fee'
	WHEN 'SSFE' THEN 'Savings Search Fee'
	WHEN 'SDFE' THEN 'Savings Stamp Duty Fee'
	WHEN 'SAFE' THEN 'Saving Account Manitenance Fee'
	
	END AS [event_type], 
	fees,
	0 AS [debit],
	amount AS [credit],
	[description],
	Currencies.code as [currency_code]	
	FROM [dbo].[SavingEvents]
	INNER JOIN [dbo].[SavingContracts] ON SavingContracts.id = SavingEvents.contract_id
	INNER JOIN [dbo].[SavingProducts] ON SavingContracts.product_id = SavingProducts.id
	INNER JOIN [dbo].[Currencies] ON SavingProducts.currency_id = Currencies.id
	WHERE contract_id = @saving_id AND SavingEvents.deleted = 0 
	AND SavingEvents.code NOT IN ('SVWE', 'SDTE', 'SODE')
	) AS T
	WHERE 
	(T.code IN ('SMFE', 'SVAE', 'SOFE', 'SIFE', 'SSFE', 'SDFE', 'SAFE') AND T.fees > 0) 
	OR (T.code IN ('SIPE') AND T.credit > 0) 
	OR T.code IN ('SVIE', 'SVDE', 'SCTE', 'SOCE', 'SVDC', 'SVRE', 'SVCE', 'SVWE', 'SDTE', 'SODE', 'SVLD')
	ORDER BY id
END
