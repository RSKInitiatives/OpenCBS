CREATE PROCEDURE dbo.Rep_Collection_Sheet 
@beginDate DATETIME
,@endDate DATETIME
,@disbursed_in INT
,@display_in INT
, @user_id INT
, @subordinate_id INT
, @branch_id INT
AS BEGIN
	SELECT i.contract_id
	, i.expected_date
	, c.contract_code
	, al.amount
	, al.olb
	, cl.name AS client_name
	, t.city
	, d.name AS district_name
	, u.first_name + ' ' + u.last_name AS loan_officer_name
	, COALESCE(t.personal_phone, t.home_phone, secondary_personal_phone, secondary_home_phone) AS phone_number
	, i.principal - i.prepaid_principal AS principal
	, i.interest - i.prepaid_interest AS interest
	, dbo.GetXR(p.currency_id, @display_in, @beginDate) AS exchange_rate
	, i.principal + i.interest - i.prepaid_principal - i.prepaid_interest total
	FROM dbo.ExpectedInstallments_MC(@beginDate, @endDate, @disbursed_in, @display_in, @user_id, @subordinate_id, @branch_id) AS i
	LEFT JOIN dbo.Contracts AS c ON c.id = i.contract_id
	LEFT JOIN dbo.Credit AS cr ON cr.id = c.id
	LEFT JOIN dbo.ActiveLoans_MC(@beginDate, @disbursed_in, @display_in, @branch_id) AS al ON al.id = c.id
	LEFT JOIN dbo.Projects AS j ON j.id = c.project_id
	LEFT JOIN dbo.Tiers AS t ON t.id = j.tiers_id
	LEFT JOIN dbo.Clients AS cl ON cl.id = t.id
	LEFT JOIN dbo.Districts AS d ON d.id = t.district_id
	LEFT JOIN dbo.Users AS u ON u.id = cr.loanofficer_id
	LEFT JOIN dbo.Packages AS p ON p.id = cr.package_id
	ORDER BY i.expected_date
END
