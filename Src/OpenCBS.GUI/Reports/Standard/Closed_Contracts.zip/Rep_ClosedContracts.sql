CREATE PROCEDURE Rep_ClosedContracts
	@beginDate DATETIME,
	@endDate DATETIME,
	@disbursed_in INT,
	@display_in INT,
	@branch_id INT
AS
BEGIN
	--DECLARE @beginDate     DATETIME = CAST(DATEADD(M, -1, GETDATE()) AS DATE),
	--		@endDate       DATETIME = CAST(GETDATE() AS DATE),
	--		@disbursed_in  INT = 0,
	--		@display_in    INT = 1,
	--		@branch_id     INT = 0

	select
		c.contract_code
		, pk.name
		, cl.name client_name
		, u.first_name + ' ' + u.last_name loan_officer
		, cr.amount * dbo.GetXR(cu.id, @display_in, closed.date) amount
		, disbursed.date disb_date
		, closed.date close_date
		, cu.name currency
	from
		dbo.Contracts c
	left join
		dbo.Credit cr on cr.id = c.id
	left join
		dbo.Projects pr on pr.id = c.project_id
	left join
		dbo.Tiers tr on tr.id = pr.tiers_id
	left join
		dbo.Clients cl on cl.id = tr.id
	left join
		dbo.Packages pk on pk.id = cr.package_id
	left join
		dbo.Users u on u.id = cr.loanofficer_id
	left join
		dbo.Currencies cu on cu.id = pk.currency_id
	inner join (
		select
			contract_id
			, min(event_date) date
		from
			dbo.ContractEvents
		where
			event_type = 'LODE'
			and is_deleted = 0
		group by
			contract_id
		) disbursed on disbursed.contract_id = c.id
	inner join (
		select
			contract_id
			, max(event_date) date
		from
			dbo.ContractEvents
		where
			event_type = 'LOCE'
			and is_deleted = 0
		group by
			contract_id
		) closed on closed.contract_id = c.id
	where
		(tr.branch_id = @branch_id OR 0 = @branch_id)
		and (cu.id = @disbursed_in OR 0 = @disbursed_in)
		and (cast(closed.date as date) between @beginDate and @endDate)
	order by
		close_date
		, loan_officer
END

