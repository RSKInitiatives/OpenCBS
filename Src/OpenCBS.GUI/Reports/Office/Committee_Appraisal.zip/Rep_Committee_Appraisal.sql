--declare @contract_id int = 12



SELECT LEFT(credit.amount,LEN(credit.amount)-3) AS amountb,credit.interest_rate, NB_OF_INSTALLMENT, CONTRACT_CODE, start_date, 
	   persons.first_name+' '+persons.last_name AS client_name,
	   [father_name],[identification_data],users.first_name+' '+users.[last_name] AS lo_name, 	   

	   (SELECT [value]
		FROM [GeneralParameters] WHERE [KEY] = 'MFI_NAME') AS mfi_name,

		100*credit.interest_rate AS interest_rate_percentage,
		currencies.code AS currency_code,
		InstallmentTypes.name AS installment_type,
		Branches.name AS branch,
		ISNULL(contracts.loan_purpose, ' ') AS loan_purpose,
		EconomicActivities.name AS economic_activity,
		contracts.credit_commitee_date AS credit_commitee_date,
		ISNULL(contracts.comments, ' ') AS commentb,
		ISNULL(contracts.credit_commitee_comment, ' ') AS credit_commitee_comment,
		ISNULL(contracts.credit_commitee_code,' ') AS credit_commitee_code,            

		CASE 
		WHEN contracts.status=1 THEN 'pending' 
		WHEN contracts.status=2 THEN 'validated' 
		WHEN contracts.status=3 THEN 'refused' 
		WHEN contracts.status=4 THEN 'abandonned' 
		WHEN contracts.status=5 THEN 'active' 
		WHEN contracts.status=6 THEN 'closed' 
		WHEN contracts.status=7 THEN 'written off' 
		WHEN contracts.status=8 THEN 'postponed' 
		WHEN contracts.status=9 THEN 'deleted' 
		ELSE ' '
		END AS status

FROM credit 
	INNER JOIN 	 contracts ON CONTRACts.id =credit.id 
    INNER JOIN 	Packages ON Packages.id=credit.package_id
	INNER JOIN 	 projects ON projects.id = contracts.[project_id]
	INNER JOIN 	 tiers ON [Tiers].id = projects.[tiers_id] 
	INNER JOIN	 persons ON persons.id = tiers.id
	INNER JOIN currencies ON currencies.id=Packages.currency_id 
	INNER JOIN InstallmentTypes ON InstallmentTypes.id=Packages.installment_type
	INNER JOIN Branches ON Branches.code=contracts.branch_code
	INNER JOIN EconomicActivities ON EconomicActivities.id=contracts.activity_id
	INNER JOIN	 [Users] ON [Users].id = [loanofficer_id]
	 
WHERE credit.id=@contract_id