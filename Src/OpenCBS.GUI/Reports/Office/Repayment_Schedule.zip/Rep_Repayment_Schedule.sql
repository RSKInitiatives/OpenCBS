--declare @contract_id INT = 12, @userId INT = 2

	SELECT LEFT(credit.amount,LEN(credit.amount)-3) AS amountb,credit.interest_rate, NB_OF_INSTALLMENT, CONTRACT_CODE, start_date, 
	   persons.first_name+' '+persons.last_name AS client_name,
	   [father_name],[identification_data],users.first_name+' '+users.[last_name] AS lo_name, 	   

	   (SELECT [value]
		FROM [GeneralParameters] WHERE [KEY] = 'MFI_NAME') AS mfi_name,
	    
	    c.name AS curname,
		currencies.code AS currency_code,
		Branches.name AS branch


FROM credit 
	INNER JOIN 	 contracts ON CONTRACts.id =credit.id 
    INNER JOIN 	Packages ON Packages.id=credit.package_id
	INNER JOIN 	 projects ON projects.id = contracts.[project_id]
	INNER JOIN 	 tiers ON [Tiers].id = projects.[tiers_id] 
	INNER JOIN	 persons ON persons.id = tiers.id
	INNER JOIN currencies ON currencies.id=Packages.currency_id 
	INNER JOIN Branches ON Branches.code=contracts.branch_code
	INNER JOIN	 [Users] ON [Users].id = [loanofficer_id]
	LEFT JOIN	 Currencies c ON c.id = Packages.currency_id
	 
WHERE credit.id=@contract_id
		SELECT i.number, i.capital_repayment, i.interest_repayment,
	cr.amount - SUM(i2.capital_repayment) AS olb, i.capital_repayment + i.interest_repayment AS total,
	i.expected_date
	FROM dbo.Installments AS i
	LEFT JOIN dbo.Credit AS cr ON cr.id = i.contract_id
	LEFT JOIN dbo.Installments AS i2 ON i.contract_id = i2.contract_id AND i2.number <= i.number
	WHERE i.contract_id = @contract_id
	GROUP BY cr.amount, i.contract_id, i.number, i.capital_repayment, i.interest_repayment, i.expected_date